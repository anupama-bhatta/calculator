package MainPackage;

/* 
    Author: Anupama Bhatta
    Date: 01/16/2018
    Description: Program that presents Heart Rate Calculator and BMI Calculator to the user to interact with.
*/
public class Program {
    public static void main(String[] args) {
        UI_Form form = new UI_Form();
        form.setVisible(true);
    }
    
}
